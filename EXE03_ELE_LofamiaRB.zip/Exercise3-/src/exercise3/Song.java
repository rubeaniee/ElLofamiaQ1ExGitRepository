/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise3;

/**
 *
 * @author bnsru
 */
public class Song {
    private String title;
    private int spotifyStreams;
    private double ratingOutOf10;
    public Song(String k, int n, double m){
        title = k;
        spotifyStreams = n;
        ratingOutOf10 = m;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the spotifyStreams
     */
    public int getSpotifyStreams() {
        return spotifyStreams;
    }

    /**
     * @param spotifyStreams the spotifyStreams to set
     */
    public void setSpotifyStreams(int spotifyStreams) {
        this.spotifyStreams = spotifyStreams;
    }

    /**
     * @return the ratingOutOf10
     */
    public double getRatingOutOf10() {
        return ratingOutOf10;
    }

    /**
     * @param ratingOutOf10 the ratingOutOf10 to set
     */
    public void setRatingOutOf10(double ratingOutOf10) {
        this.ratingOutOf10 = ratingOutOf10;
    }
}
