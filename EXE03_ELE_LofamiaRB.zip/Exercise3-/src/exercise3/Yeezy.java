/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise3;

/**
 *
 * @author bnsru
 */
public class Yeezy {
    private String Brand;
    private String Designer;
    private double yearMade = 2015;
    private int retailPrice = 230; // (in $dollars)
    public Yeezy(String l, String m){
        Brand = l;
        Designer = m;
    }

    /**
     * @return the Brand
     */
    public String getBrand() {
        return Brand;
    }

    /**
     * @param Brand the Brand to set
     */
    public void setBrand(String Brand) {
        this.Brand = Brand;
    }

    /**
     * @return the Designer
     */
    public String getDesigner() {
        return Designer;
    }

    /**
     * @param Designer the Designer to set
     */
    public void setDesigner(String Designer) {
        this.Designer = Designer;
    }

    /**
     * @return the yearMade
     */
    public double getYearMade() {
        return yearMade;
    }

    /**
     * @param yearMade the yearMade to set
     */
    public void setYearMade(double yearMade) {
        this.yearMade = yearMade;
    }

    /**
     * @return the retailPrice
     */
    public int getRetailPrice() {
        return retailPrice;
    }

    /**
     * @param retailPrice the retailPrice to set
     */
    public void setRetailPrice(int retailPrice) {
        this.retailPrice = retailPrice;
    }
}
