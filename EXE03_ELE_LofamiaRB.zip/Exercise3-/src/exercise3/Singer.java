/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise3;

/**
 *
 * @author bnsru
 */
public class Singer {
    private String name;
    private int noOfPerformances;
    private double earnings;
    private String favoriteSong;
    private int audience;
    private String title;
    private static int totalPerformances = 0;
    public void performForAudience(int audience){
        noOfPerformances++;
        setEarnings(audience * 100);
        setTotalPerformances(getTotalPerformances() + 1); 
    }
    public void performForAudience(Singer otherSinger, int numberOfPeople){
        noOfPerformances++;
        earnings += numberOfPeople * (100/2);
        otherSinger.setNoOfPerformances(otherSinger.getNoOfPerformances() + 1);
        otherSinger.earnings = numberOfPeople * (100/2);
        setTotalPerformances(getTotalPerformances() + 2); 
    }
    public void changeFavSong(String song){
        setFavoriteSong(song);
        setTitle(song);
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    public Singer(String name){
        this.name = name;
    }

    /**
     * @return the noOfPerformances
     */
    public int getNoOfPerformances() {
        return noOfPerformances;
    }

    /**
     * @param noOfPerformances the noOfPerformances to set
     */
    public void setNoOfPerformances(int noOfPerformances) {
        this.noOfPerformances = noOfPerformances;
    }

    /**
     * @return the earnings
     */
    public double getEarnings() {
        return earnings;
    }

    /**
     * @param earnings the earnings to set
     */
    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }

    /**
     * @return the favoriteSong
     */
    public String getFavoriteSong() {
        return favoriteSong;
    }

    /**
     * @param favoriteSong the favoriteSong to set
     */
    public void setFavoriteSong(String favoriteSong) {
        this.favoriteSong = favoriteSong;
    }

    /**
     * @return the audience
     */
    public int getAudience() {
        return audience;
    }

    /**
     * @param audience the audience to set
     */
    public void setAudience(int audience) {
        this.audience = audience;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the totalPerformances
     */
    public static int getTotalPerformances() {
        return totalPerformances;
    }

    /**
     * @param aTotalPerformances the totalPerformances to set
     */
    public static void setTotalPerformances(int aTotalPerformances) {
        totalPerformances = aTotalPerformances;
    }
}
