/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercise3;

/**
 *
 * @author bnsru
 */
public class Exercise3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Yeezy yeezy1 = new Yeezy("Adidas", "Kanye West");
        Yeezy yeezy2 = new Yeezy("Adidas", "Kanye West");
        Yeezy yeezy3 = new Yeezy("Adidas", "Kanye West");
        
        Song song1 = new Song("Runaway", 464292186, 10);
        Song song2 = new Song("Devil In A New Dress", 346841560, 10);
        Song song3 = new Song("Ghost Town", 406990709, 10);
        
        Singer singer1 = new Singer("Kanye West");
        singer1.getName();
        singer1.getFavoriteSong();
        singer1.performForAudience(12);
        singer1.changeFavSong(song2.getTitle());
        
        Singer singer2 = new Singer("Tyler, the Creator");
        singer2.getFavoriteSong();
        singer2.changeFavSong("SWEET / I THOUGHT YOU WANTED TO DANCE");
        singer2.performForAudience(8);
     
        singer2.performForAudience(singer1, 100);
        System.out.println("Total Performances: " + Singer.getTotalPerformances());
        System.out.println(singer1.getName() + " fave song is changed to " + singer1.getTitle());
    }
    
}
