package exercise4;
import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author bnsru
 */

    public class RockPaperScissors{
	public static void main(String[] args){
		Move rock = new Move("Rock");
		Move paper = new Move("Paper");
		Move scissors = new Move("Scissors");
                
                Move computer = new Move(null);
                Move user = new Move(null);
                Move result = new Move(null);
		
		rock.setStrongAgainst(scissors);
		paper.setStrongAgainst(rock);
		scissors.setStrongAgainst(paper);
                
                int response = 0;	
		int roundsToWin = 2;
		Scanner scan = new Scanner(System.in); 
                
		for(int k = 0; 0 < response || response < 4; k++){
                    
                System.out.println("Welcome to Rock, Paper, Scissors! Input a number to signify the action you want to do.");
                System.out.println("1: Play the Game");
                System.out.println("2: Change number of wins to end the game");
                System.out.println("3: Exit Application");
                
                int userScore = 0;
                int computerScore = 0;
                
                response = scan.nextInt();
                if(response == 1){  
                  for(int i = 0; userScore < roundsToWin || computerScore < roundsToWin; i++){
                     int random = (int) Math.floor(Math.random()*3) + 1;
                     if(random == 1){
                         computer.computerMove = rock;
                     } else if(random == 2){
                         computer.computerMove = paper;
                     } else {
                         computer.computerMove = scissors;
                     }
                     
                
                    System.out.println("The computer has selected its move. What is your move?");
                    System.out.println("1: Rock");
                    System.out.println("2: Paper");
                    System.out.println("3: Scissors");
                    
                    int userInput = scan.nextInt();
                    if (userInput == 1){
                        user.playerMove = rock;
                    } else if(userInput == 2){
                        user.playerMove = paper;
                    } else if(userInput == 3){
                        user.playerMove = scissors;
                    } else {
                        System.out.println("Please input a number from 1-3");
                    }
                    int outcome = result.compareMoves(user.playerMove, computer.computerMove);
                    
                        if(outcome == 0){
                            System.out.println("Player chose " + user.playerMove.getName() + ", Computer chose "  + computer.computerMove.getName() + ". Player wins round!");
                            userScore++;
                            System.out.println("Player: " + userScore + " - Computer: " + computerScore);
                        } else if(outcome == 1){
                            System.out.println("Player chose " + user.playerMove.getName() + ", Computer chose " + computer.computerMove.getName() + ". Computer wins round!");
                            computerScore++;
                            System.out.println("Player: " + userScore + " - Computer: " + computerScore);
                        } else {
                            System.out.println("Player chose " + user.playerMove.getName() + ", Computer chose " + computer.computerMove.getName() + ". Round is tied!");
                            System.out.println("Player: " + userScore + " - Computer: " + computerScore);
                        }
                        
                        if(userScore == roundsToWin){
                            System.out.println("Player Wins!");
                            break;
                        } else if(computerScore == roundsToWin){
                            System.out.println("Computer Wins!");
                            break;
                        }
                }    
                }
                else if(response == 2){
                    System.out.println("Input number of round wins required to win the game");
                    int numOfWins = scan.nextInt();
                    if(numOfWins > 0){
                        roundsToWin = numOfWins;
                        System.out.println("New setting has been saved.");
                    } else {
                        System.out.println("Please input a positive integer");
                    }
                    
                } else if(response == 3){
                    System.out.println("Thanks for playing!");
                    break;
                } else {
                    System.out.println("Please input numbers only from the three options above.");
                }
                       
	}
        }
}

