package ex05_ele_lofamiarb;

import java.util.*;

public class Store {
  private String name;
  private double earnings;
  private ArrayList<Item> itemList;
  private static ArrayList<Store> storeList = new ArrayList();

  public Store(String name){
    // Initialize name to parameter and earnings to zero
    this.name = name;
    earnings = 0;
    // Initialize itemList as a new ArrayList
    this.itemList = new ArrayList<>();
    // add 'this' store to storeList
    this.storeList.add(this);
  }

  public String getName(){
    return name;
  }
  public double getEarnings(){
    return earnings;
  }
  public void sellItem(int index){
    // check if index is within the size of the itemList (if not, print statement that there are only x items in the store)
    if(index > this.itemList.size() - 1){
        System.out.println("There are only " + this.itemList.size() + " items in the store.");
    } 
    // get Item at index from itemList and add its cost to earnings
    else {
        Item kit = this.itemList.get(index);
        earnings += kit.getCost();
    // print statement indicating the sale
        System.out.println("You have successfully purchased" + kit.getName() + " for PHP" + kit.getCost() + ".");
    }

  }
  public void sellItem(String name){
    // check if Item with given name is in the itemList (you will need to loop over itemList) (if not, print statement that the store doesn't sell it)
    boolean kit = false;
    // get Item from itemList and add its cost to earnings
    for(Item e: this.itemList){
        String item = e.getName();
        if(item.equalsIgnoreCase(name) == true){
            earnings += e.getCost();
    // print statement indicating the sale      
            System.out.println("You have successfully purchased " + e.getName() + " for PHP" + e.getCost() + ".");
            kit = true;
        }
    }
    if(kit == false){
        System.out.println("This store does not sell" + name + ".");
    }
  }
  public void sellItem(Item i){
    // check if Item i exists in the store (there is a method that can help with this) (if not, print statement that the store doesn't sell it)
    boolean name = false;
    // get Item i from itemList and add its cost to earnings
    for(int j = 0; j < this.itemList.size(); j++){
        if(this.itemList.get(j) == i){
            earnings += this.itemList.get(j).getCost();
    // print statement indicating the sale
         System.out.println(this.itemList.get(j).getName()+ ", " + this.itemList.get(j).getCost());
            name = true;
        }
    } if(name == false){
        System.out.println("The store doesn't sell it.");
    }
  }
  public void addItem(Item i){
    // add Item i to store's itemList
    itemList.add(i);
  }
  public void filterType(String type){
    // loop over itemList and print all items with the specified type
    for(Item i: itemList){
        if(i.getType().equals(type) == true){
            System.out.println(i.getName() + ", " + i.getCost());
        }
    }
  }
  public void filterCheap(double maxCost){
    // loop over itemList and print all items with a cost lower than or equal to the specified value
    for(Item i: itemList){
        if(i.getCost() <= maxCost){
            System.out.println(i.getName() + ", " + i.getCost());
        }
    }
  }
  public void filterExpensive(double minCost){
    // loop over itemList and print all items with a cost higher than or equal to the specified value
    for(Item i: itemList){
        if(i.getCost() >= minCost){
            System.out.println(i.getName() + ", " + i.getCost());
        }
    }
  }
  public static void printStats(){
    // loop over storeList and print the name and the earnings'Store.java'
    for(int i = 0; i < storeList.size(); i++){
        System.out.println(storeList.get(i).getName() + ", " + storeList.get(i).getEarnings());
    }
  }
}
