/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercise1;

/**
 *
 * @author bnsru
 */
public class Exercise1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
               
        String p1Name = "LeBron James";
        String p1Specialty = "Playmaking";
        int p1Seasons = 20;
        
        String p2Name = "Michael Jordan";
        String p2Specialty = "Mid-Range";
        int p2Seasons = 15;
        
        String p3Name = "Kyrie Irving";
        String p3Specialty = "Ball Handling";
        int p3Seasons = 12;
        
        int avrgSeasons = (p1Seasons + p2Seasons +p3Seasons)/3;
        boolean longestCareer = p1Seasons > p2Seasons;
        boolean sameSpecialty = p2Specialty.equals(p3Specialty);
        
        System.out.println("Player 1:");
        
        System.out.println("Name: " + p1Name);
        System.out.println("Name: " + p1Specialty);
        System.out.println("Name: " + p1Seasons);
        
        
        System.out.println("Player 2:");
        
        System.out.println("Name: " + p2Name);
        System.out.println("Name: " + p2Specialty);
        System.out.println("Name: " + p2Seasons);
        
        
        System.out.println("Player 3:");
        
        System.out.println("Name: " + p3Name);
        System.out.println("Name: " + p3Specialty);
        System.out.println("Name: " + p3Seasons);
        
        System.out.println("Average Career Length of Players: " + avrgSeasons);
        System.out.println("LeBron James has had the longest career out of the three players: " + longestCareer);
        System.out.println("Michael Jordan and Kyrie Irving both specialize in the same field of basketball: " + sameSpecialty);
    }
    
}
