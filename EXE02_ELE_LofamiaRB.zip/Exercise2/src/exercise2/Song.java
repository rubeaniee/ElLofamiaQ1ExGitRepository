/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise2;

/**
 *
 * @author bnsru
 */
public class Song {
    String title;
    int spotifyStreams;
    double ratingOutOf10;
    public Song(String k, int n, double m){
        title = k;
        spotifyStreams = n;
        ratingOutOf10 = m;
    }
}
