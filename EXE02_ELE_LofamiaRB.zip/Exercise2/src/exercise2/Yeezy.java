/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise2;

/**
 *
 * @author bnsru
 */
public class Yeezy {
    String singer;
    String song;
    double rankingInSpotify = 12;
    int listeners = 57902462; //source: spotify
    public Yeezy(String l, String m){
        singer = l;
        song = m;
    }
}
