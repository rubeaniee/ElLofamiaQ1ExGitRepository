/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise2;

/**
 *
 * @author bnsru
 */
public class Singer {
    String name;
    int noOfPerformances;
    double earnings;
    String favoriteSong;
    int audience;
    String title;
    public void performForAudience(int audience){
        noOfPerformances = audience;
        earnings = audience * 100;
        audience = audience;
    }
    public void changeFavSong(String song){
        favoriteSong = song;
        title = song;
    }
}
